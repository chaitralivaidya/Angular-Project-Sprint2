import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-claim',
  templateUrl: './create-claim.component.html',
  styleUrls: ['./create-claim.component.css']
})
export class CreateClaimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
