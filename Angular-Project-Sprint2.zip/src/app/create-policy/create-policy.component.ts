import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-policy',
  templateUrl: './create-policy.component.html',
  styleUrls: ['./create-policy.component.css']
})
export class CreatePolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
