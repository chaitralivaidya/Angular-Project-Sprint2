import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar-insured',
  templateUrl: './nav-bar-insured.component.html',
  styleUrls: ['./nav-bar-insured.component.css']
})
export class NavBarInsuredComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
