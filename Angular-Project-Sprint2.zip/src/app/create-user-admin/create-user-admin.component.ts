import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-user-admin',
  templateUrl: './create-user-admin.component.html',
  styleUrls: ['./create-user-admin.component.css']
})
export class CreateUserAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
