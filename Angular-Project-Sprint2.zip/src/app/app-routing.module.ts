import { NavBarAdminComponent } from './nav-bar-admin/nav-bar-admin.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { CreateUserAdminComponent } from './create-user-admin/create-user-admin.component';
import { ViewPolicyAdminComponent } from './view-policy-admin/view-policy-admin.component';
import { CreateClaimComponent } from './create-claim/create-claim.component';
import { ViewClaimComponent } from './view-claim/view-claim.component';
import { CreatePolicyComponent } from './create-policy/create-policy.component';

const routes: Routes = [{path:'login' , component:LoginComponent},
                        {path:'navbar' , component:NavBarComponent},
                        {path:'home' , component:HomeComponent},
                        {path:'navbaradmin' , component:NavBarAdminComponent},
                        {path:'createuseradmin' , component:CreateUserAdminComponent},
                        {path:'viewpolicyadmin' , component:ViewPolicyAdminComponent},
                        {path:'createclaim' , component:CreateClaimComponent},
                        {path:'viewclaim' , component:ViewClaimComponent},
                        {path:'createpolicy' , component:CreatePolicyComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
