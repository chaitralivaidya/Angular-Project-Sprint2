import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar-agent',
  templateUrl: './nav-bar-agent.component.html',
  styleUrls: ['./nav-bar-agent.component.css']
})
export class NavBarAgentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
