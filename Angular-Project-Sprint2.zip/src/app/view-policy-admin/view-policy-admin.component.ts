import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-policy-admin',
  templateUrl: './view-policy-admin.component.html',
  styleUrls: ['./view-policy-admin.component.css']
})
export class ViewPolicyAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
