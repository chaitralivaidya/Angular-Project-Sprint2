import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-claim',
  templateUrl: './view-claim.component.html',
  styleUrls: ['./view-claim.component.css']
})
export class ViewClaimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
